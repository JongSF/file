<html>
   <body>
      <?php
         $url = "{imap.gmail.com:993/imap/ssl/novalidate-cert}INBOX";
         $id = "denard.wyne@gmail.com";
         $pwd = "bywrnysudfjszagv";
         $mailbox = imap_open($url, $id, $pwd);
         if($mailbox){
			 $num = imap_num_msg($mailbox);
			 print("Number of messages: ".$num."\n");
         
            print("Connection established....");
         } else {
            print("Connection failed");
         }
      ?>
   </body>
</html>
