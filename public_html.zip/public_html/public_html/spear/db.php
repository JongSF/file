<?php
  $curr_db = "sniperphish";
  $conn = mysqli_connect("localhost","root","sQJ3,klMjjlY",$curr_db);

  if (mysqli_connect_errno()) {
    die("DB connection failed!");
  } 
?>