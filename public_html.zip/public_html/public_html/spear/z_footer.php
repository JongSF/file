<footer class="footer text-center">
   © 2021 | All Rights Reserved
</footer>