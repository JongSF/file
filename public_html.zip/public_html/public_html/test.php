<?php
echo `whoami`;
